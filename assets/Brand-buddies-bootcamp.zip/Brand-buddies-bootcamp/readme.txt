Team Name: Brand Buddies
Team Members
1) Meet Parmar
2) Viktor Kim
3) Samaya Kafle
4) Sneh Patel
